/**
 * Created by andrew.yang on 7/27/2017.
 */
export class Product {
    title: string;
    brand?: string;
    price?: number;
    description?: string;
    image?: string
}