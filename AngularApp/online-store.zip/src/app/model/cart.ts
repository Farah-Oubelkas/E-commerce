/**
 * Created by Andrew on 7/30/2017.
 */
import {Product} from "./product";

export class Cart {
    product:Product;
    quantity:number;
}