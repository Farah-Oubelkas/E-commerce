/**
 * Created by andrew.yang on 7/27/2017.
 */
import {CategoryComponent} from "./category.component";

export const categoryRoutes=[
    {
        path:'',
        component:CategoryComponent
    },
];