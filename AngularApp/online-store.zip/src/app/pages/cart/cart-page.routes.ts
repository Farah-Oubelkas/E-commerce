/**
 * Created by andrew.yang on 7/27/2017.
 */
import {CartPageComponent} from "./cart-page.component";

export const cartPageRoutes=[
    {
        path:'',
        component:CartPageComponent
    },
];