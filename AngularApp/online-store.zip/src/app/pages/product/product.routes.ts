/**
 * Created by andrew.yang on 7/27/2017.
 */
import {ProductComponent} from "./product.component";

export const productRoutes=[
    {
        path:':id',
        component:ProductComponent
    },
];